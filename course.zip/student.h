/**
 * @file student.h
 * @author Laeek Ahmed (shaikl3@mcmaster.ca)
 * @brief file for managing struct Student and related functions.
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

/**
 * @brief struct Student to store student's first and last name, id, grades and no. of grades
 *
 */

typedef struct _student
{
  char first_name[50];
  char last_name[50];
  char id[11]; /**< student's 11 digit id no. */
  double *grades;
  int num_grades;
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student *generate_random_student(int grades);
