/**
 * @mainpage course+student functions demonstration
 *
 * main file merges course.c & student.c functions to perfrom the following tasks:
 * - Printing the details of the course MATH101 created in main()
 * - Printing the details of the top scorer for this course.
 * - Printign the count and details of all the students who passed the course.
 * @file main.c
 * @author Laeek Ahmed (shaikl3@mcmaster.ca)
 * @brief Runs demonstration code for course and student library methods
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * The main func creates a course MATH101 allocating memory using calloc.
 * It then enrolls 20 randomly generated studnets into the course and then prints this course's attributes.
 * The the top scrorer's (student's) details are printed.
 * Finally it displays (prints) all the passing students details and the count.
 *
 * @return int
 */

int main()
{
  srand((unsigned)time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  /*
  for loop which enrolls 20 randomly generated students having 8 courses (8 grades)
  into MATH101 course.
  */

  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));

  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  /*
  List of passing students for the course MATH101.
   */
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++)
    print_student(&passing_students[i]);

  return 0;
}