/**
 * @file course.h
 * @author Laeek Ahmed (shaikl3@mcmaster.ca)
 * @brief file for managing struct Course and related functions.
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief struct to store course name, code , list of students and its count.
 *
 */

typedef struct _course
{
  char name[100];
  char code[10];     /**< course's 10 digit code */
  Student *students; /**< List of students (of type Students) in the course */
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course *course);
Student *passing(Course *course, int *total_passing);
